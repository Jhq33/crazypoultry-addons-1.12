-----------------------------------------------------------------------
|                                                                     |
|	Venantes 2                                                    |
|                                                                     |
-----------------------------------------------------------------------

Maintainer: Zirah on Blackhand (EU, Alliance)
Webpage: http://zirah.dunkelklingen.de/venantes.php


Venantes is mod to help the Hunter manage the aspects, tracking, traps 
and pet spells, potions, drink/food and messages.

It provides a variety of buttons for common spells in an easy-to-use, 
small, convinient package.

The idea was adapted from Serenity and Necrosis LdC to make 
it usable by hunters. I needed something like it for my hunter :-)

Venantes will provide you a sphere and 10 buttons. The sphere will 
display information and the outer buttons will provide quick access 
for several things.

Venantes is splitted into 3 mods. 

Venantes - the main mod
VenantesOptions - configuration dialog
SphereLoader - loads Venantes only if the toon is a hunter

Sphere
=> Left click/Right click to activate a configured action
=> You can put the Venantes Sphere wherever you want
=> Detach the buttons from the sphere and move them whereever you like.
=> Show or remove any of the visible buttons
=> Rotate the buttons around the sphere to fit your settings

Sphere Circle - selectable 
=> Nothing!
=> Current Mana
=> Current Health
=> Current XP
=> Current Pet Mana
=> Current Pet Health
=> Current Pet XP

Sphere Text - selectable 
=> Nothing!
=> Ammo Count (turns yellow at 600, red at 200)
=> Current Mana
=> Current Health
=> Current Pet Mana
=> Current Pet Health
=> Drink/Food Count

Buttons
=> Aspect Menu
=> Tracking Menu
=> Traps Menu
=> Pet Menu
=> 3 Action buttons 
---- Left click/Right click to activate a configured action
=> Mount Button
---- Right click to use hearthstone
=> Potion Button
---- Left click: Health Potion
---- Right click: Mana Potion
=> Drink/Food Button
---- Left click: Drink
---- Right click: Food

Random chat messages
=> available for Hunter's Mark, TranqShot, Pet Call, Pet Revive and mounting.
=> configurable to a short, raid-ready version (disables pet/mount messages)


