-----------------------------------------------------------------------
|                                                                     |
|	Venantes 2 SphereLoader                                       |
|                                                                     |
-----------------------------------------------------------------------

Maintainer: Zirah on Blackhand (EU, Alliance)
Webpage: http://www.wowinterface.com/downloads/info6155-Venantes.html

This is a loader addon for Venantes 2 or other class specific addons.

It is a really simple addon. No configurations dialog, No commands. 

All it does is to check the character class and load an addon.

    Hunter = Venantes
    Mage = Cryolysis
    Priest = Serenity
    Shaman = Spirit Sphere
    Warlock = Necrosis LdC

The addons need to be marked as load on demand check the *.toc file 
of the addon for:

    ## LoadOnDemand: 1
