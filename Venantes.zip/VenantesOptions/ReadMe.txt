-----------------------------------------------------------------------
|                                                                     |
|	Venantes 2 Options                                            |
|                                                                     |
-----------------------------------------------------------------------

Maintainer: Zirah on Blackhand (EU, Alliance)
Webpage: http://www.wowinterface.com/downloads/info6155-Venantes.html

Options Dialog for Venantes 2

This is a part of Venantes 2. It is a seperate addon to allow to 
load on demand.

Check ..\Venantes\ReadMe.txt and ..\Venantes\Changelog.txt